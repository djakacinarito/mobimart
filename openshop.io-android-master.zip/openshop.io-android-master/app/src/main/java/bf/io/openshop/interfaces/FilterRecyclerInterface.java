package bf.io.openshop.interfaces;


public interface FilterRecyclerInterface {
}
