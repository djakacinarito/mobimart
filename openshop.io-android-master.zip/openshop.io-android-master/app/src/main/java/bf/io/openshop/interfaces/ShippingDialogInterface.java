package bf.io.openshop.interfaces;

import bf.io.openshop.entities.delivery.Shipping;

public interface ShippingDialogInterface {
    void onShippingSelected(Shipping shipping);

}
