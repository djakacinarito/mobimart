package bf.io.openshop.interfaces;

public interface FilterDialogInterface {

    void onFilterSelected(String filterUrl);

    void onFilterCancelled();
}
